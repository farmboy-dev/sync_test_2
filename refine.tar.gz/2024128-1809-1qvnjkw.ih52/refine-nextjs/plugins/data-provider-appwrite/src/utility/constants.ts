export const APPWRITE_URL = "https://refine.appwrite.org/v1";
export const APPWRITE_PROJECT = "61c4368b4e349";
export const APPWRITE_TOKEN_KEY = "appwrite-jwt";
