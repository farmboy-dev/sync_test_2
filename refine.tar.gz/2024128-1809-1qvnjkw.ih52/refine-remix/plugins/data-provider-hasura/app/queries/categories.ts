export const CATEGORIES_QUERY = ["id", "title"];
