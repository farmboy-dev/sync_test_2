module.exports = {
    client: {
        service: {
            name: "SpaceX",
            url: "https://api.spacex.land/graphql/",
        },
    },
};
