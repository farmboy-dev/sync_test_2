export * from "./appwriteClient";
<%_ if (answers["ui-framework"] === "antd") { _%>
export * from "./normalize";
<%_ } _%>
