export * from "./supabaseClient";
