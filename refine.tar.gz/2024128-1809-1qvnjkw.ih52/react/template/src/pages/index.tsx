export default function Home() {
    return (
        <main>
            <h1><%= name %></h1>
            <p>superplate react app</p>
        </main>
    );
}
