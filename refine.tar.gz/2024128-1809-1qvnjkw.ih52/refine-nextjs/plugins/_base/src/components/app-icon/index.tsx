'use client'

import React from "react";

export const AppIcon: React.FC = () => {
    return (
    <%_ if (selectedSvg) { _%>
        <%- selectedSvg %>
    <%_ } _%>
    )
}