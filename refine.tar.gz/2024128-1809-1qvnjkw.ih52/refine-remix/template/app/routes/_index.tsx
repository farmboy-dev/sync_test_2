import { WelcomePage } from "@refinedev/core";

export default function Index() {
    return <WelcomePage />;
}
